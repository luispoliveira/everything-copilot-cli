# Vitrina Interativa de Minerais — Lousal

**Implementation Plan** | Date: 2026-04-20 | Prepared for: Internal Developer

---

## 1. Executive Summary

The Lousal Mineral Display Case is a museum-grade interactive installation featuring a 6,950 mm wide vitrina divided into 3 glass panels. Visitors touch one of 6 designated zones on the front glass, triggering a coordinated response: the corresponding mineral spotlight brightens, all others dim, and informational content is projected onto the rear panel. The system automatically returns to a contemplative standby state after 45 seconds of inactivity.

- **Overall complexity**: 🔴 Complex (multi-subsystem, 230V AC, museum continuous operation)
- **Estimated total duration**: 16 weeks
- **Key risks**: Glass touch sensitivity through thick museum glass; 230V AC lighting wiring (requires qualified electrician); rear projection geometry constraints; long-term continuous operation stability

---

## 2. System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    VITRINA FRONTAL (6950mm)                  │
│  [Pano 1: 2 zonas]   [Pano 2: 2 zonas]   [Pano 3: 2 zonas] │
│  [Cobre Z1][Cobre Z2] [Cobre Z3][Cobre Z4] [Cobre Z5][Z6]   │
└─────────────┬───────────────────────────────────────────────┘
              │ Fios de cobre (interior vitrina, pela retaguarda)
              ▼
┌─────────────────────────┐
│   ESP32 DevKit v1        │  Touch pins T0–T5 (GPIO 4,0,2,15,13,12)
│   (dentro da vitrina,    │  Alimentação: USB 5V
│    acesso pela retaguarda│  Comunicação: WiFi → MQTT
└──────────┬──────────────┘
           │ MQTT over WiFi (LAN Lousal)
           ▼
┌─────────────────────────────────────────────────────────────┐
│              PC CENTRAL (Windows/macOS/Linux)                │
│                                                             │
│  Python Coordinator (state machine)                         │
│  ┌─────────────────┐   ┌──────────────────────────────────┐ │
│  │ MQTT Subscriber │   │ Standby / Active / Timeout Logic │ │
│  └────────┬────────┘   └──────────┬───────────────────────┘ │
│           │                       │                         │
│           ▼                       ▼                         │
│  ┌────────────────┐    ┌──────────────────────┐            │
│  │ DMX Controller │    │ Projection Controller │            │
│  │ (python-dmx /  │    │ (Pygame / web display)│            │
│  │  pyenttec)     │    │                      │            │
│  └────────┬───────┘    └──────────┬───────────┘            │
└───────────┼─────────────────────── ┼───────────────────────┘
            │ USB                    │ HDMI
            ▼                        ▼
┌───────────────────┐     ┌─────────────────────────────┐
│ Enttec DMX USB Pro│     │ Projector (short-throw)      │
│ (USB→DMX512)      │     │ → Rear-projection film/screen│
└────────┬──────────┘     │   on back panel of vitrina   │
         │ DMX512 (3-pin) └─────────────────────────────┘
         ▼
┌────────────────────────────────────────────┐
│  6× Dimmable Warm White Spotlights          │
│  (DMX dimmable, 1 per mineral, inside      │
│   vitrina, 230V AC via SSR or DMX dimmer   │
│   pack — see C2 for full wiring)           │
└────────────────────────────────────────────┘
```

**Communication protocols:**

- ESP32 → PC: MQTT over WiFi (port 1883, LAN only)
- PC → Lighting: USB Serial via Enttec DMX USB Pro → DMX512
- PC → Projection: HDMI video output (secondary display or projector as display)
- PC → ESP32: MQTT (heartbeat / configuration only)

**Power distribution:**

- ESP32: 5V USB from PC or USB charger inside vitrina
- PC: Standard mains socket (230V AC)
- Spotlights: 230V AC through DMX dimmer pack (⚡ see Safety Warnings in C2)
- Projector: 230V AC, dedicated socket

**Data flow (touch event):**

1. Visitor touches Zone N on glass
2. ESP32 detects capacitance change on pin TN → publishes MQTT message `vitrina/touch` with payload `{"zone": N}`
3. Python coordinator receives message → transitions state machine to ACTIVE(N)
4. Coordinator sends DMX values: channel N = 255 (full), all others = 40 (dim)
5. Coordinator updates projection display: show content for zone N
6. Timer resets: after 45s inactivity → return to STANDBY (all lights 160, projection off)

---

## 3. Challenge Breakdown

---

### C1 — Touch Detection on Glass (6 zones)

#### 3.1 Overview

- **Objective**: Detect a visitor's finger contact on 6 predefined zones on the front glass of the vitrina and report which zone was touched to the central PC.
- **Difficulty**: 🟡 Medium
- **Estimated duration**: 3 weeks (including calibration on-site)

#### 3.2 Requirements

**Functional:**

- Detect touch reliably through glass (4–8mm thickness typical for museum vitrina)
- Distinguish 6 independent zones, no crosstalk
- Report zone number via WiFi within 200ms of touch
- Work reliably in ambient museum light conditions (no IR interference risk — capacitive system)

**Non-functional:**

- False positive rate < 1% (no accidental triggers from nearby movement)
- False negative rate < 5% (not missing genuine touches)
- Operate 8h/day continuously without drift
- Low-profile installation (copper pads inside glass, invisible from visitor side)

**Constraints:**

- Copper pad wiring must be routed to vitrina rear — no visible cables on front
- System must auto-recalibrate baseline drift (ESP32 native touch does this automatically)

#### 3.3 Component Selection

| Component                      | Model/Part Number                  | Qty   | Est. Cost (€) | Datasheet/Reference                                                                                       | Purpose                         |
| ------------------------------ | ---------------------------------- | ----- | ------------- | --------------------------------------------------------------------------------------------------------- | ------------------------------- |
| Microcontroller                | ESP32 DevKit v1 (38-pin)           | 1     | ~8€           | [Espressif Datasheet](https://www.espressif.com/sites/default/files/documentation/esp32_datasheet_en.pdf) | Touch detection + WiFi          |
| Copper foil tape               | 3M 1181 (or equivalent), 25mm wide | 2m    | ~6€           | [3M 1181 Product Page](https://www.3m.com/3M/en_US/p/d/b00012264/)                                        | Touch electrodes on inner glass |
| Shielded cable                 | 6-core shielded, 24AWG             | 4m    | ~8€           | —                                                                                                         | Wiring from pads to ESP32       |
| USB cable + 5V charger         | USB-A to Micro-USB, 5V 1A          | 1     | ~5€           | —                                                                                                         | Power for ESP32                 |
| Enclosure                      | ABS project box 120×80×40mm        | 1     | ~4€           | —                                                                                                         | Mount ESP32 inside vitrina rear |
| Jumper wires + terminal blocks | Generic                            | 1 set | ~4€           | —                                                                                                         | Connections                     |

**Total C1 estimated cost: ~35€**

**Key decision — ESP32 native touch vs. MPR121:**
The ESP32 has 10 built-in capacitive touch pins (T0–T9). For 6 zones this is sufficient with no external IC. The MPR121 (NXP) is discontinued. ESP32 native touch is well-documented, simpler to implement, and the built-in auto-calibration handles baseline drift in museum environments.

**Alternative**: If glass thickness > 8mm proves to reduce sensitivity too much, use a dedicated controller: [AT42QT1070](https://ww1.microchip.com/downloads/en/DeviceDoc/AT42QT1070-Datasheet.pdf) (7-channel, I2C, more sensitive amplifier).

#### 3.4 Circuit/Wiring Notes

**ESP32 Touch Pin Mapping:**

| Zone | Mineral Position | ESP32 Touch Pin | GPIO Number | Copper Pad Location |
| ---- | ---------------- | --------------- | ----------- | ------------------- |
| Z1   | Pano 1, Left     | T0              | GPIO4       | Pano 1, left zone   |
| Z2   | Pano 1, Right    | T1              | GPIO0       | Pano 1, right zone  |
| Z3   | Pano 2, Left     | T2              | GPIO2       | Pano 2, left zone   |
| Z4   | Pano 2, Right    | T3              | GPIO15      | Pano 2, right zone  |
| Z5   | Pano 3, Left     | T4              | GPIO13      | Pano 3, left zone   |
| Z6   | Pano 3, Right    | T5              | GPIO12      | Pano 3, right zone  |

**Wiring notes:**

- Attach copper foil tape (approx. 80×80mm square) to the **inner surface** of the glass at each zone position
- Solder a single 24AWG wire to each pad using conductive adhesive or low-temperature solder
- Route wires along the inner bottom edge of the vitrina to the rear access point
- Use shielded cable from the vitrina rear to the ESP32 enclosure — the shield connects to ESP32 GND only at the ESP32 end (not at the pad end) to avoid ground loops
- Keep wires away from 230V AC lighting cables (minimum 50mm separation, or use additional shielding)
- Do NOT connect any pull-up or pull-down resistors to touch pins — the ESP32 touch circuit is internal

**⚠️ Important**: GPIO0 and GPIO2 are used for ESP32 boot mode. To use T1 (GPIO0) and T2 (GPIO2) as touch inputs:

- During normal operation: fine — the pins are in touch input mode after boot
- For flashing firmware: temporarily disconnect the touch wires or use the EN/BOOT buttons

**Alternative safe pin mapping** (avoids boot-sensitive pins):

- Use T6=GPIO14, T7=GPIO27, T8=GPIO33, T9=GPIO32 instead of T1 and T2

#### 3.5 Firmware Tasks

- [ ] **F1.1 — Set up PlatformIO development environment** 🟢
  - **What**: Install PlatformIO IDE extension in VS Code and create a new ESP32 project
  - **Why**: PlatformIO is the professional tool for ESP32 firmware development. It manages libraries, compilation, and flashing automatically.
  - **Prerequisites**: VS Code installed. No prior electronics knowledge needed.
  - **Resources**:
    - [PlatformIO Installation Guide](https://platformio.org/install/ide?install=vscode)
    - [ESP32 Getting Started with PlatformIO](https://randomnerdtutorials.com/vs-code-platformio-ide-esp32-esp8266-arduino/)
  - **Steps**:
    1. Open VS Code → Extensions → search "PlatformIO IDE" → Install
    2. Click PlatformIO icon (alien head) in sidebar → "New Project"
    3. Name: `vitrina-touch`, Board: `Espressif ESP32 Dev Module`, Framework: `Arduino`
    4. Open `platformio.ini` — verify it contains `board = esp32dev`
    5. Open `src/main.cpp` — replace content with a basic blink: `digitalWrite(LED_BUILTIN, HIGH); delay(1000);`
    6. Connect ESP32 via USB → click Upload (→ arrow in bottom bar)
    7. The onboard LED should blink
  - **Definition of Done**: ESP32 LED blinks at 1 second interval. Serial Monitor (115200 baud) shows "Hello World" printed every second.
  - **Estimated time**: 2 hours

- [ ] **F1.2 — Read raw capacitive touch values from all 6 pins** 🟢
  - **What**: Read the raw capacitance value from each of the 6 touch pins and print them to the Serial Monitor
  - **Why**: Before you can detect a touch, you need to understand what values the sensor produces when untouched vs. touched. Every installation is different — glass thickness, humidity, and cable length all affect the numbers.
  - **Prerequisites**: F1.1 complete. Understand what a GPIO pin is (a numbered connection point on the ESP32).
  - **Resources**:
    - [ESP32 Touch Sensor Tutorial](https://randomnerdtutorials.com/esp32-touch-pins-arduino-ide/)
    - [ESP32 touchRead() API](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/touch.html)
  - **Steps**:
    1. In `src/main.cpp`, write this code:
    ```cpp
    void setup() {
      Serial.begin(115200);
    }
    void loop() {
      Serial.print("T0:"); Serial.print(touchRead(T0));
      Serial.print(" T1:"); Serial.print(touchRead(T1));
      Serial.print(" T2:"); Serial.print(touchRead(T2));
      Serial.print(" T3:"); Serial.print(touchRead(T3));
      Serial.print(" T4:"); Serial.print(touchRead(T4));
      Serial.print(" T5:"); Serial.println(touchRead(T5));
      delay(200);
    }
    ```

    2. Upload and open Serial Monitor at 115200 baud
    3. Observe values WITHOUT touching anything — write down these "baseline" numbers
    4. Touch each copper pad one at a time — write down "touched" values
    5. Expected: baseline ~40–80, touched ~5–20 (through glass may be ~20–35 baseline, ~10–15 touched)
    6. If values don't change when touching: check wiring continuity with a multimeter (resistance between pad and ESP32 pin should be < 10Ω)
  - **Definition of Done**: Serial Monitor shows 6 values updating 5 times/second. Values measurably decrease when each pad is touched individually. You have noted baseline and touched values for all 6 zones.
  - **Estimated time**: 1.5 hours

- [ ] **F1.3 — Implement touch detection with threshold and debounce** 🟡
  - **What**: Convert raw touch readings into reliable touch events with configurable thresholds and debounce logic
  - **Why**: Raw readings are noisy — a single reading below threshold does not mean a real touch. You need to confirm the touch persists for at least 50ms to avoid false triggers.
  - **Prerequisites**: F1.2 complete. Understand what a "threshold" is: a value below which we consider the pad "touched".
  - **Resources**:
    - [ESP32 Touch Interrupt Tutorial](https://randomnerdtutorials.com/esp32-touch-pins-arduino-ide/)
    - [Software Debouncing Explained](https://docs.arduino.cc/built-in-examples/digital/Debounce/)
  - **Steps**:
    1. Define thresholds based on your F1.2 measurements. Example:
    ```cpp
    // Set these based on YOUR measured values from F1.2
    // Rule: threshold = (baseline + touched) / 2
    const int TOUCH_THRESHOLD[6] = {25, 25, 25, 25, 25, 25};
    const int DEBOUNCE_MS = 80;  // ms touch must persist to be valid
    ```

    2. Implement debounce: track the time when each pin first goes below threshold. Only fire event if still below threshold after DEBOUNCE_MS
    3. Implement "touch released" detection: fire a release event when pin goes above threshold again
    4. Print to Serial: `"ZONE 1 TOUCHED"` and `"ZONE 1 RELEASED"`
    5. Test each zone 20 times — count false positives (triggers without touching) and false negatives (misses)
    6. Adjust TOUCH_THRESHOLD per zone if needed
  - **Definition of Done**: Each of the 6 zones reliably prints TOUCHED/RELEASED. Tested 20 times each: ≥ 18/20 correct detections, 0 false positives over 5 minutes idle.
  - **Estimated time**: 3 hours

- [ ] **F1.4 — Connect ESP32 to WiFi and set up MQTT client** 🟡
  - **What**: Connect the ESP32 to the Lousal museum WiFi network and establish a connection to an MQTT broker running on the central PC
  - **Why**: WiFi + MQTT is how the ESP32 tells the PC which zone was touched. MQTT is a lightweight messaging protocol — think of it as a postal system where the ESP32 sends a letter to a specific "address" (topic) and the PC is subscribed to receive it.
  - **Prerequisites**: F1.3 complete. Know the WiFi SSID and password for Lousal museum network. Know the IP address of the central PC.
  - **Resources**:
    - [ESP32 MQTT Tutorial with PubSubClient](https://randomnerdtutorials.com/esp32-mqtt-publish-subscribe-arduino-ide/)
    - [PubSubClient Library Docs](https://pubsubclient.knolleary.net/)
  - **Steps**:
    1. In `platformio.ini`, add library: `lib_deps = knolleary/PubSubClient @ ^2.8`
    2. Create `include/config.h` with your credentials:
    ```cpp
    #define WIFI_SSID "Lousal_WiFi"        // replace with real SSID
    #define WIFI_PASSWORD "your_password"  // replace with real password
    #define MQTT_SERVER "192.168.1.100"    // replace with PC IP address
    #define MQTT_PORT 1883
    #define MQTT_TOPIC_TOUCH "vitrina/touch"
    #define MQTT_TOPIC_STATUS "vitrina/status"
    ```

    3. ⚠️ SECURITY: Add `include/config.h` to `.gitignore` — NEVER commit WiFi passwords to git
    4. In `main.cpp`, implement WiFi connection with reconnect logic
    5. Implement MQTT client with reconnect logic (MQTT can drop connection — must auto-reconnect)
    6. On touch event, publish: `{"zone": 1}` to topic `vitrina/touch`
    7. Test: install [MQTT Explorer](https://mqtt-explorer.com/) on PC, observe incoming messages when touching pads
  - **Definition of Done**: MQTT Explorer on PC shows `vitrina/touch` messages with correct zone number within 200ms of touching each pad. ESP32 auto-reconnects after WiFi disruption (test by briefly disconnecting from router).
  - **Estimated time**: 3 hours

- [ ] **F1.5 — Implement heartbeat and watchdog** 🟡
  - **What**: Send a periodic "I'm alive" message to the PC every 10 seconds, and use the ESP32 hardware watchdog to auto-restart if the firmware hangs
  - **Why**: This is a museum installation that must run for months unattended. The heartbeat lets staff and the remote developer know the ESP32 is working. The watchdog ensures it auto-recovers from any software freeze.
  - **Prerequisites**: F1.4 complete.
  - **Resources**:
    - [ESP32 Hardware Watchdog Timer](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/wdts.html)
    - [Arduino esp_task_wdt reference](https://github.com/espressif/arduino-esp32/blob/master/libraries/ESP32/examples/WatchdogTimer/WatchdogTimer.ino)
  - **Steps**:
    1. Every 10 seconds, publish to `vitrina/status`: `{"status": "alive", "uptime_s": 1234}`
    2. Enable hardware watchdog with 30 second timeout: `esp_task_wdt_init(30, true)`
    3. Call `esp_task_wdt_reset()` in the main loop
    4. Test watchdog: comment out the reset call, verify ESP32 restarts after 30s
  - **Definition of Done**: MQTT Explorer shows `vitrina/status` alive messages every 10 seconds. ESP32 automatically restarts within 35 seconds if the loop hangs (simulated by adding `while(1){}` temporarily).
  - **Estimated time**: 2 hours

---

### C2 — Dimmable Spotlight Control (DMX512)

#### 3.1 Overview

- **Objective**: Control 6 individual warm white spotlights inside the vitrina via DMX512 from the central PC. Each spotlight should be independently dimmable to support mineral highlight scenes.
- **Difficulty**: 🔴 Advanced (involves 230V AC — requires qualified electrician for mains wiring)
- **Estimated duration**: 3 weeks

> ⚡ **DANGER: MAINS VOLTAGE (230V AC)**
>
> This section involves work with mains electricity (230V AC).
> **Risk of LETHAL electric shock.**
>
> Mandatory precautions:
>
> - ALWAYS disconnect mains power before touching any wiring inside the vitrina
> - All 230V AC wiring inside the vitrina MUST be done or verified by a **qualified electrician**
> - The DMX dimmer pack handles 230V — keep it physically separated from low-voltage electronics
> - Use appropriate wire gauges (minimum 1.5mm² for 230V loads)
> - Install a fused IEC inlet rated for total load (6 spotlights × max wattage)
> - Never work alone on energized circuits
> - The ESP32, MQTT cables, and touch wiring are all LOW VOLTAGE (5V/3.3V) — keep them far from 230V wiring

#### 3.2 Requirements

**Functional:**

- Dim each of 6 spotlights independently (0–100%)
- Support "scene" presets: STANDBY (all at 60%), HIGHLIGHT zone N (zone N at 100%, others at 15%), TRANSITION (smooth 2-second fade)
- DMX commands from PC arrive via USB (Enttec DMX USB Pro)

**Non-functional:**

- No visible flicker (PWM dimming frequency must be > 100Hz — DMX dimmers handle this)
- Color temperature: 2700–3000K warm white (museum mineral presentation standard)
- Fixture wattage: recommend 10–15W per spotlight (energy efficient, low heat inside enclosed vitrina)

#### 3.3 Component Selection

| Component            | Model/Part Number                                                  | Qty | Est. Cost (€) | Datasheet/Reference                                                                           | Purpose                        |
| -------------------- | ------------------------------------------------------------------ | --- | ------------- | --------------------------------------------------------------------------------------------- | ------------------------------ |
| DMX USB Interface    | Enttec DMX USB Pro (SKU 70304)                                     | 1   | ~90€          | [Enttec DMX USB Pro](https://www.enttec.com/product/controls/dmx-usb-interfaces/dmx-usb-pro/) | PC to DMX512 bridge            |
| DMX Dimmer Pack      | Showtec Multidim MK3 (4ch) + 2ch extension OR 6ch rack dimmer      | 1   | ~180–300€     | [Showtec Multidim MK3](https://www.highlite.com/en/showtec-multidim-mk3.html)                 | 230V AC dimming for spotlights |
| Warm White Spotlight | PAR16/GU10 fixture, DMX addressable OR standard GU10 + dimmer pack | 6   | ~25–40€ each  | —                                                                                             | Mineral illumination           |
| GU10 LED bulb        | 2700K, 7W, dimmable                                                | 6   | ~5€ each      | —                                                                                             | Light source                   |
| DMX cable            | 3-pin XLR, 110Ω, 3m                                                | 2   | ~8€ each      | —                                                                                             | PC to dimmer, daisy-chain      |
| DMX terminator       | 3-pin XLR 120Ω                                                     | 1   | ~4€           | —                                                                                             | End of DMX chain               |
| Mains power strip    | Fused, 6-outlet, 16A                                               | 1   | ~25€          | —                                                                                             | Power for dimmer pack          |

**Total C2 estimated cost: ~450–550€**

**Key decision — DMX dimmer pack vs. individual DMX fixtures:**
Using a standard DMX dimmer pack (like Showtec Multidim) with regular dimmable GU10 bulbs is cheaper and simpler than buying 6 individual DMX-addressable fixtures. The dimmer pack handles the 230V switching internally; the developer only works with 5V DMX signal from the Enttec interface.

**Alternative**: Philips Hue or DALI system — avoid. DALI adds complexity. Hue lacks reliable local API for museum use. DMX is the industry standard.

#### 3.4 Circuit/Wiring Notes

**DMX channel assignment:**

| DMX Channel | Zone | Spotlight | Fixture Location |
| ----------- | ---- | --------- | ---------------- |
| CH 1        | Z1   | Mineral 1 | Pano 1, Left     |
| CH 2        | Z2   | Mineral 2 | Pano 1, Right    |
| CH 3        | Z3   | Mineral 3 | Pano 2, Left     |
| CH 4        | Z4   | Mineral 4 | Pano 2, Right    |
| CH 5        | Z5   | Mineral 5 | Pano 3, Left     |
| CH 6        | Z6   | Mineral 6 | Pano 3, Right    |

**Signal path (low voltage — safe for developer):**

```
PC USB → Enttec DMX USB Pro → XLR cable → DMX Dimmer Pack input → DMX Terminator
```

**Power path (⚡ 230V AC — electrician required):**

```
Wall socket → Fused strip → Dimmer Pack mains input
Dimmer Pack outputs → 6 spotlight fixtures (inside vitrina)
```

**Wiring considerations:**

- Set dimmer pack starting address to DMX channel 1 (rotary switches on device)
- Install DMX terminator on the last device in the chain
- Route DMX signal cable separately from 230V power cables inside vitrina
- Label all cables at both ends with zone number

#### 3.6 Software Integration Tasks (PC side)

- [ ] **S2.1 — Install pyenttec library and test DMX output** 🟢
  - **What**: Install the Python library for the Enttec DMX USB Pro and send test values to all 6 channels
  - **Why**: Before integrating with touch events, verify the PC can control the lights independently
  - **Prerequisites**: Python 3.10+ installed. Enttec device connected via USB. Dimmer pack powered and set to correct DMX address.
  - **Resources**:
    - [pyenttec on PyPI](https://pypi.org/project/pyenttec/)
    - [Enttec DMX USB Pro Windows Driver](https://www.enttec.com/product/controls/dmx-usb-interfaces/dmx-usb-pro/)
  - **Steps**:
    1. `pip install pyenttec`
    2. Find the COM port (Windows: Device Manager → Ports; macOS/Linux: `ls /dev/tty.*`)
    3. Test script:

    ```python
    import enttec_usb_dmx_pro as enttec
    import time

    dmx = enttec.EnttecDMXUSBPro('/dev/ttyUSB0')  # adjust port

    # Test: fade all lights from off to full
    for value in range(0, 256, 5):
        universe = [0] * 513
        for ch in range(1, 7):
            universe[ch] = value
        dmx.send_dmx(universe)
        time.sleep(0.05)
    ```

    4. Observe: all 6 spotlights should fade from off to full brightness
    5. Test individual channels: set CH1=255, all others=0 — only spotlight 1 should be on

  - **Definition of Done**: Each spotlight responds individually to DMX commands from Python. Fade animation works visually smooth.
  - **Estimated time**: 2 hours

- [ ] **S2.2 — Implement lighting scene presets** 🟢
  - **What**: Create Python functions for the three required lighting scenes
  - **Why**: Encapsulating scenes as functions makes the coordinator code clean and easy to maintain by Lousal staff
  - **Steps**:
    1. Create `lighting.py` with these functions:

    ```python
    STANDBY_LEVEL = 160   # ~63% — soft ambient
    HIGHLIGHT_LEVEL = 255  # 100%
    DIM_LEVEL = 40        # ~16% — others dimmed
    FADE_STEPS = 20
    FADE_DELAY = 0.05     # 1 second total fade

    def set_standby(dmx):
        """All minerals at soft ambient level"""
        universe = [0] * 513
        for ch in range(1, 7):
            universe[ch] = STANDBY_LEVEL
        dmx.send_dmx(universe)

    def set_highlight(dmx, zone: int):
        """Zone 1-6 at full, others dimmed. Fade transition."""
        # Get current values then fade to target
        target = [DIM_LEVEL] * 7  # index 0 unused
        target[zone] = HIGHLIGHT_LEVEL
        universe = [0] * 513
        for ch in range(1, 7):
            universe[ch] = target[ch]
        dmx.send_dmx(universe)
    ```

    2. Test each scene function manually

  - **Definition of Done**: `set_standby()` lights all 6 at medium brightness. `set_highlight(3)` makes spotlight 3 bright and all others dim. Transition is visually smooth.
  - **Estimated time**: 1.5 hours

---

### C3 — Rear Projection System

#### 3.1 Overview

- **Objective**: Display informational content about the selected mineral on the rear panel of the vitrina using a projector. Content switches based on the active zone, and disappears during standby.
- **Difficulty**: 🟡 Medium
- **Estimated duration**: 2 weeks

#### 3.2 Requirements

**Functional:**

- Display content for 6 minerals (text, images, diagrams)
- Switch content within 500ms of receiving zone selection
- Black screen during STANDBY mode
- Content visible through the rear projection surface at vitrina interior depths (~800mm)

**Non-functional:**

- Projection must be legible in museum ambient light
- Aspect ratio: typically 16:9 or custom depending on panel dimensions
- Projector must fit in the space behind the vitrina (>830mm throw recommended) OR use ultra-short-throw positioned inside
- Resolution: minimum 1280×720

#### 3.3 Component Selection

| Component             | Model/Part Number                           | Qty                      | Est. Cost (€) | Reference                                                                        | Purpose                         |
| --------------------- | ------------------------------------------- | ------------------------ | ------------- | -------------------------------------------------------------------------------- | ------------------------------- |
| Short-throw projector | BenQ MW560 or similar                       | 1                        | ~450–600€     | [BenQ MW560](https://www.benq.com/en-us/projector/home-entertainment/mw560.html) | Content display                 |
| Rear projection film  | Grayhill or Pro Display film, self-adhesive | TBD (measure rear panel) | ~15€/m²       | [Pro Display Film](https://prodisplay.com/products/rear-projection-film/)        | Diffuse rear projection surface |
| HDMI cable            | 5m active HDMI                              | 1                        | ~15€          | —                                                                                | PC to projector                 |

**Projection geometry note**: With 830mm vitrina depth, confirm projector throw ratio. A projector with 1.5:1 throw ratio needs ~1.1m to project 720mm wide. Consider positioning projector **outside the vitrina** at the rear, projecting through the back panel.

#### 3.4 Circuit/Wiring Notes

- Projector connected to PC via HDMI as a **secondary display** (extended desktop)
- The projection application runs full-screen on the secondary display
- No electronic complexity — purely software + mechanical positioning
- Route HDMI cable through the vitrina rear access point

#### 3.6 Software Integration Tasks

- [ ] **S3.1 — Build projection content display application** 🟡
  - **What**: Create a Python/Pygame application that shows full-screen mineral content on the secondary display, controlled by the coordinator
  - **Why**: Pygame provides simple full-screen display control. The coordinator sends commands to switch content.
  - **Prerequisites**: Python 3.10+ and pip. Basic Python knowledge.
  - **Resources**:
    - [Pygame Getting Started](https://www.pygame.org/docs/)
    - [Pygame multi-monitor full-screen](https://stackoverflow.com/questions/6957194/fullscreen-pygame-on-second-monitor)
  - **Steps**:
    1. `pip install pygame`
    2. Create `projection.py`:

    ```python
    import pygame
    import os

    CONTENT_DIR = "content"  # folder with images/info per zone

    class ProjectionDisplay:
        def __init__(self, display_index=1):
            pygame.init()
            monitors = pygame.display.get_num_displays()
            if display_index >= monitors:
                display_index = 0  # fallback to primary
            info = pygame.display.Info()
            self.screen = pygame.display.set_mode(
                (1280, 720),
                pygame.FULLSCREEN | pygame.NOFRAME,
                display=display_index
            )
            pygame.display.set_caption("Vitrina Lousal")
            self.current_zone = None
            self.show_standby()

        def show_standby(self):
            self.screen.fill((0, 0, 0))  # black
            pygame.display.flip()

        def show_zone(self, zone: int):
            img_path = os.path.join(CONTENT_DIR, f"zone_{zone}.jpg")
            if os.path.exists(img_path):
                img = pygame.image.load(img_path)
                img = pygame.transform.scale(img, (1280, 720))
                self.screen.blit(img, (0, 0))
                pygame.display.flip()

        def tick(self):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    return False
            return True
    ```

    3. Prepare placeholder images: `content/zone_1.jpg` through `content/zone_6.jpg`
    4. Test manually by calling `show_zone(1)` through `show_zone(6)` and `show_standby()`

  - **Definition of Done**: Full-screen display shows correct image for each zone number. Black screen shown for standby. Images switch within 500ms.
  - **Estimated time**: 3 hours

- [ ] **S3.2 — Prepare mineral content assets** 🟢
  - **What**: Create or source 6 content images (one per mineral) in 1280×720px format
  - **Why**: The projection system needs actual content to display. Even placeholder assets are needed for testing.
  - **Steps**:
    1. Create `content/` folder in project root
    2. For each of the 6 minerals, create a `zone_N.jpg` image (1280×720px)
    3. Content should include: mineral name, scientific classification, brief description, origin
    4. Use tools like Canva or Adobe Express if graphic design is not available
    5. Optimize file size: each image < 2MB for fast loading
  - **Definition of Done**: 6 image files exist in `content/` folder, display correctly via `ProjectionDisplay.show_zone()`.
  - **Estimated time**: 4 hours (content creation time variable)

---

### C4 — Central Coordination Software (State Machine)

#### 3.1 Overview

- **Objective**: A Python application running on the central PC that receives touch events via MQTT, controls the lighting and projection subsystems, manages standby/active state, and provides a simple status interface for museum staff.
- **Difficulty**: 🟡 Medium
- **Estimated duration**: 3 weeks

#### 3.2 Requirements

**Functional:**

- Subscribe to MQTT topic `vitrina/touch` and `vitrina/status`
- State machine: STANDBY → ACTIVE(zone) → STANDBY (after 45s timeout)
- Trigger lighting scene change and projection content on zone selection
- If same zone touched while active: reset the 45s timer, no visual change
- If different zone touched while active: transition to new zone immediately
- Provide simple log output showing current state and last touch
- Remote monitoring: developer can check status via MQTT from anywhere on the same WiFi

**Non-functional:**

- Auto-start on PC boot (Windows Task Scheduler or macOS LaunchAgent)
- Graceful handling of ESP32 disconnect (if heartbeat missing > 30s: log warning, do not crash)
- All state transitions logged with timestamp to a log file

#### 3.6 Software Integration Tasks

- [ ] **S4.1 — Install Python dependencies and MQTT broker** 🟢
  - **What**: Install Mosquitto MQTT broker on the central PC and the required Python libraries
  - **Why**: The ESP32 sends MQTT messages to a broker (a message relay server) running on the PC. The Python coordinator subscribes to those messages. Mosquitto is the most common and simplest MQTT broker.
  - **Resources**:
    - [Mosquitto Download](https://mosquitto.org/download/)
    - [paho-mqtt Python library](https://pypi.org/project/paho-mqtt/)
  - **Steps**:
    1. Download and install Mosquitto from mosquitto.org
    2. Start Mosquitto as a service (Windows: it installs automatically; macOS: `brew install mosquitto && brew services start mosquitto`)
    3. Test broker: open two terminals. In terminal 1: `mosquitto_sub -h localhost -t test`. In terminal 2: `mosquitto_pub -h localhost -t test -m "hello"`. Terminal 1 should print "hello".
    4. Install Python libraries: `pip install paho-mqtt pyenttec pygame`
    5. Configure Mosquitto to allow connections from ESP32 (edit `mosquitto.conf`): add `listener 1883` and `allow_anonymous true`
    6. Find PC IP address (`ipconfig` on Windows, `ifconfig` on macOS) — this is what goes in ESP32 `config.h`
  - **Definition of Done**: Mosquitto running as service. `mosquitto_pub` / `mosquitto_sub` test works. Python can import `paho.mqtt.client` without errors.
  - **Estimated time**: 1.5 hours

- [ ] **S4.2 — Implement the main coordinator state machine** 🟡
  - **What**: Write the main Python application that wires together touch detection, lighting, projection, and timeout logic
  - **Why**: This is the "brain" of the system. It receives touch events and tells all other subsystems what to do.
  - **Steps**:
    1. Create `coordinator.py`:

    ```python
    import json
    import time
    import threading
    import logging
    from datetime import datetime
    import paho.mqtt.client as mqtt
    import enttec_usb_dmx_pro as enttec
    from lighting import set_standby, set_highlight
    from projection import ProjectionDisplay

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.FileHandler('vitrina.log'),
            logging.StreamHandler()
        ]
    )

    STANDBY_TIMEOUT = 45  # seconds
    DMX_PORT = '/dev/ttyUSB0'  # adjust for your OS
    MQTT_BROKER = 'localhost'
    MQTT_PORT = 1883

    class VitrinaCoordinator:
        def __init__(self):
            self.state = 'STANDBY'
            self.active_zone = None
            self.last_touch_time = None
            self.dmx = enttec.EnttecDMXUSBPro(DMX_PORT)
            self.projection = ProjectionDisplay(display_index=1)
            self.mqtt_client = mqtt.Client()
            self.mqtt_client.on_connect = self._on_connect
            self.mqtt_client.on_message = self._on_message
            self._timeout_thread = None

        def start(self):
            self._transition_standby()
            self.mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
            self.mqtt_client.loop_start()
            logging.info("Vitrina coordinator started")
            try:
                while True:
                    self.projection.tick()
                    time.sleep(0.05)
            except KeyboardInterrupt:
                self.stop()

        def stop(self):
            self.mqtt_client.loop_stop()
            self._transition_standby()
            logging.info("Vitrina coordinator stopped")

        def _on_connect(self, client, userdata, flags, rc):
            if rc == 0:
                client.subscribe('vitrina/touch')
                client.subscribe('vitrina/status')
                logging.info("MQTT connected")
            else:
                logging.error(f"MQTT connection failed: rc={rc}")

        def _on_message(self, client, userdata, msg):
            if msg.topic == 'vitrina/touch':
                try:
                    payload = json.loads(msg.payload.decode())
                    zone = int(payload.get('zone', 0))
                    if 1 <= zone <= 6:
                        self._handle_touch(zone)
                except (json.JSONDecodeError, ValueError) as e:
                    logging.warning(f"Invalid touch message: {e}")

        def _handle_touch(self, zone: int):
            logging.info(f"Touch: Zone {zone} | State: {self.state}")
            self.last_touch_time = time.time()
            if self.state == 'STANDBY' or self.active_zone != zone:
                self._transition_active(zone)
            # Reset timeout timer regardless
            self._reset_timeout()

        def _transition_active(self, zone: int):
            self.state = 'ACTIVE'
            self.active_zone = zone
            set_highlight(self.dmx, zone)
            self.projection.show_zone(zone)
            logging.info(f"-> ACTIVE Zone {zone}")

        def _transition_standby(self):
            self.state = 'STANDBY'
            self.active_zone = None
            set_standby(self.dmx)
            self.projection.show_standby()
            logging.info("-> STANDBY")

        def _reset_timeout(self):
            if self._timeout_thread and self._timeout_thread.is_alive():
                self._timeout_thread.cancel()
            self._timeout_thread = threading.Timer(
                STANDBY_TIMEOUT, self._transition_standby
            )
            self._timeout_thread.start()

    if __name__ == '__main__':
        coordinator = VitrinaCoordinator()
        coordinator.start()
    ```

    2. Test state machine logic: touch a zone, verify lights and projection respond; wait 45 seconds, verify standby returns; touch another zone mid-interaction, verify smooth transition

  - **Definition of Done**: Full flow works: touch Z1 → highlight Z1 + show content → wait 45s → standby → touch Z3 → highlight Z3 + show content 3. Log file shows all transitions with timestamps.
  - **Estimated time**: 5 hours

- [ ] **S4.3 — Configure auto-start on PC boot** 🟢
  - **What**: Configure the coordinator application to start automatically when the PC is switched on
  - **Why**: Museum staff must not need to manually start the software each day
  - **Steps (Windows)**:
    1. Create `start_vitrina.bat`:
    ```batch
    @echo off
    cd C:\vitrina
    python coordinator.py
    ```

    2. Open Task Scheduler → Create Task → Trigger: "At startup" → Action: run `start_vitrina.bat`
    3. Set "Run whether user is logged on or not" if using a dedicated account
  - **Steps (macOS)**:
    1. Create a LaunchAgent plist in `~/Library/LaunchAgents/com.lousal.vitrina.plist`
    2. `launchctl load ~/Library/LaunchAgents/com.lousal.vitrina.plist`
  - **Definition of Done**: Reboot the PC. Without any manual action, the coordinator is running within 60 seconds and touch events work normally.
  - **Estimated time**: 1 hour

---

### C5 — Power Supply & Physical Installation

#### 3.1 Overview

- **Objective**: Design and document the physical installation of all electronics inside and around the vitrina, including safe 230V AC distribution for lighting.
- **Difficulty**: 🔴 Advanced (230V AC — qualified electrician required)
- **Estimated duration**: 2 weeks (installation week + testing)

> ⚡ **DANGER: MAINS VOLTAGE (230V AC)**
> All 230V wiring must be performed or verified by a **licensed electrician**.
> The developer's role is limited to low-voltage (5V/12V) components and DMX signal.

#### 3.2 Physical Layout

```
VITRINA REAR ACCESS (looking from behind):

LEFT PANEL                CENTER PANEL              RIGHT PANEL
[Z1 pad wire]─────┐   [Z3 pad wire]─────┐   [Z5 pad wire]─────┐
[Z2 pad wire]─────┤   [Z4 pad wire]─────┤   [Z6 pad wire]─────┤
                  │                     │                       │
                  └─────────────────────┴───────────────────────┤
                                                                 │
                  ┌──────────────────────────────────────────────┘
                  │ (6 shielded touch wires routed along bottom rail)
                  ▼
          ┌───────────────┐
          │ ESP32 Box     │ ← 5V USB power from PC
          │ (ABS enclosure│
          │  on rear wall)│
          └───────────────┘

          ┌───────────────┐       ┌─────────────────────┐
          │ DMX Dimmer    │◄──────│ Enttec DMX USB Pro  │
          │ Pack (230V)   │  DMX  │ connected to PC USB │
          │ [ELECTRICIAN] │       └─────────────────────┘
          └───────┬───────┘
                  │ 6× 230V AC spotlight cables (inside vitrina)
                  ▼
          [SP1][SP2][SP3][SP4][SP5][SP6] — ceiling mounts inside vitrina
```

#### 3.3 Installation Checklist

- [ ] **Measure and mark** 6 touch pad locations on inner glass (coordinate with exhibition designer)
- [ ] **Apply copper foil pads** — clean glass surface with IPA first, apply foil, solder connection wire
- [ ] **Route touch wires** along bottom edge, secure with cable clips, label each wire (Z1–Z6)
- [ ] **Mount ESP32 enclosure** on rear wall, accessible for maintenance
- [ ] **Install DMX dimmer pack** — ⚡ electrician: wire 230V input and 6 spotlight outputs
- [ ] **Mount 6 spotlights** on interior ceiling, align with mineral positions
- [ ] **Route DMX signal cable** (XLR) from PC position to dimmer pack
- [ ] **Connect Enttec USB** device to PC
- [ ] **Position projector** at rear — verify throw distance, focus, keystone correction
- [ ] **Apply rear projection film** to interior back panel
- [ ] **Cable management**: all cables labeled, secured, no trip hazards
- [ ] **Electrician sign-off**: 230V wiring inspected before energizing

---

## 4. Technology Decision Matrix

### Touch Detection Technology

| Criteria            | ESP32 Native Touch | MPR121 (NXP)    | AT42QT1070 (Microchip)   | IR Touch Frame          |
| ------------------- | ------------------ | --------------- | ------------------------ | ----------------------- |
| Cost                | €0 (built-in)      | Discontinued    | ~€8/unit                 | ~€400+                  |
| Complexity          | 🟢 Simple          | 🟡 Medium       | 🟡 Medium                | 🔴 Complex              |
| Glass penetration   | Good (≤8mm)        | Better          | Best                     | N/A (IR perimeter)      |
| Junior-friendliness | High               | Medium          | Medium                   | Low                     |
| Library support     | Excellent          | Good            | Limited                  | Vendor SDK              |
| **Recommendation**  | ✅ Primary         | ❌ Discontinued | ⚠️ Fallback if glass>8mm | ❌ Overkill for 6 zones |

### Lighting Control Protocol

| Criteria            | DMX512                 | Philips Hue         | PWM Direct            | DALI      |
| ------------------- | ---------------------- | ------------------- | --------------------- | --------- |
| Cost                | ~€270 interface+dimmer | ~€300 bridge+bulbs  | ~€20                  | ~€200+    |
| Museum reliability  | ✅ Industry standard   | ⚠️ Cloud dependency | 🟢 Simple             | ✅ Good   |
| Dimming quality     | Excellent              | Good                | Variable              | Excellent |
| Junior-friendliness | Medium                 | High                | High                  | Low       |
| Scalability         | Excellent (512 ch)     | Limited             | Limited               | Good      |
| **Recommendation**  | ✅                     | ❌                  | ❌ (no scene control) | ❌        |

### Communication Protocol (ESP32 → PC)

| Criteria            | MQTT/WiFi             | USB Serial  | OSC/UDP | BLE    |
| ------------------- | --------------------- | ----------- | ------- | ------ |
| Cable-free          | ✅                    | ❌          | ✅      | ✅     |
| Reliability         | High (with reconnect) | Very High   | Medium  | Medium |
| Latency             | <100ms                | <10ms       | <50ms   | <100ms |
| Junior-friendliness | High                  | High        | Medium  | Low    |
| Remote monitoring   | ✅                    | ❌          | ❌      | ❌     |
| **Recommendation**  | ✅                    | ⚠️ Fallback | ❌      | ❌     |

---

## 5. Implementation Roadmap

### Phase 0: Environment Setup (Week 1–2)

**Dependencies**: None
**Goal**: Developer has fully working development environment, all tools installed, all components ordered

- [ ] Install PlatformIO + VS Code (Task F1.1)
- [ ] Install Python 3.10+, pip, all libraries (`pip install paho-mqtt pyenttec pygame`)
- [ ] Install Mosquitto MQTT broker and verify it starts on boot (Task S4.1)
- [ ] Install MQTT Explorer for debugging
- [ ] Order all components (see BOM below)
- [ ] Set up Git repository for project code
- [ ] Create `vitrina-touch` PlatformIO project and `vitrina-coordinator` Python project

### Phase 1: Touch Prototype (Week 2–4)

**Dependencies**: Phase 0 complete, ESP32 and copper tape received
**Goal**: ESP32 reliably detects 6 touch zones and sends MQTT messages to PC

- [ ] Read raw touch values (Task F1.2)
- [ ] Implement detection + debounce (Task F1.3)
- [ ] Connect to WiFi + MQTT (Task F1.4)
- [ ] Add heartbeat + watchdog (Task F1.5)
- [ ] Test: verify MQTT messages appear in MQTT Explorer for all 6 zones
- [ ] **Site visit 1**: Install copper pads on actual vitrina glass. Re-calibrate thresholds on-site.

### Phase 2: Lighting Control (Week 4–6)

**Dependencies**: Enttec device and dimmer pack received, ⚡ electrician has wired spotlights
**Goal**: PC can control all 6 spotlights individually via Python

- [ ] Test Enttec DMX USB Pro + dimmer (Task S2.1)
- [ ] Implement lighting scene presets (Task S2.2)
- [ ] Test all scenes visually on actual spotlights

### Phase 3: Projection System (Week 6–8)

**Dependencies**: Projector and rear projection film received, rear panel of vitrina accessible
**Goal**: PC displays correct mineral content on rear projection

- [ ] Build projection display application (Task S3.1)
- [ ] Prepare mineral content assets (Task S3.2)
- [ ] **Site visit 2**: Position projector, apply film, calibrate throw and focus
- [ ] Verify content is legible at typical visitor viewing distances

### Phase 4: Integration (Week 8–11)

**Dependencies**: Phases 1–3 complete (all subsystems working independently)
**Goal**: Complete system works end-to-end with state machine

- [ ] Implement coordinator state machine (Task S4.2)
- [ ] Integration test: touch → lights + projection → timeout → standby
- [ ] Test all edge cases: rapid multi-touch, hold touch, simultaneous zones, MQTT reconnect
- [ ] Implement auto-start (Task S4.3)

### Phase 5: On-Site Installation (Week 12–13)

**Dependencies**: Phase 4 complete, all components physically available on-site
**Goal**: System installed in final configuration at Lousal

- [ ] Execute physical installation checklist (C5)
- [ ] ⚡ Electrician: final 230V sign-off
- [ ] Full system test on-site with real vitrina geometry

### Phase 6: Validation, Documentation & Handover (Week 14–16)

**Dependencies**: Phase 5 complete
**Goal**: System validated, museum staff trained, remote support configured

- [ ] Execute full testing & validation plan (Section 6)
- [ ] Write operator manual for Lousal staff (plain language, no jargon)
- [ ] Set up remote access for developer (VPN or TeamViewer)
- [ ] Soak test: run continuously for 72 hours, log all events
- [ ] Staff training session (1 hour): how to restart, what to do if lights don't respond, how to contact developer)
- [ ] Handover document: component list, warranty contacts, spare parts to keep on-site

---

## 6. Testing & Validation Plan

### C1 — Touch Detection

| Test                  | Type        | Input                                    | Expected Output                              | Pass Criteria        |
| --------------------- | ----------- | ---------------------------------------- | -------------------------------------------- | -------------------- |
| Single zone touch     | Unit        | Finger on Zone 1 pad                     | MQTT message `{"zone":1}` published          | 19/20 trials correct |
| All zones independent | Unit        | Touch each zone separately               | Correct zone number each time                | 19/20 per zone       |
| No crosstalk          | Unit        | Touch Zone 1 while 2–6 unwired           | Only Zone 1 triggers                         | 0 false zones        |
| Idle false positive   | Reliability | No touch for 10 minutes                  | No MQTT messages published                   | 0 false triggers     |
| Reconnect recovery    | Resilience  | Disconnect WiFi for 30s, reconnect       | Touch events resume within 5s of WiFi return | Pass                 |
| Watchdog recovery     | Resilience  | Simulate firmware hang                   | ESP32 auto-restarts within 35s               | Pass                 |
| Through-glass test    | Integration | Touch on glass exterior (vitrina closed) | Touch detected reliably                      | 18/20 trials         |

### C2 — Lighting

| Test             | Type       | Input                                     | Expected Output                  | Pass Criteria             |
| ---------------- | ---------- | ----------------------------------------- | -------------------------------- | ------------------------- |
| Standby scene    | Unit       | Call `set_standby()`                      | All 6 lights at ~60%             | Visual check              |
| Highlight zone N | Unit       | Call `set_highlight(N)` for N=1..6        | Light N at 100%, others at 15%   | Visual check, all 6 zones |
| DMX reconnect    | Resilience | Unplug/replug Enttec USB                  | Lights resume control within 10s | Pass                      |
| No flicker       | Quality    | Observe lights for 1 minute at each level | No visible flicker               | Pass                      |

### C3 — Projection

| Test                 | Type        | Input                     | Expected Output                 | Pass Criteria              |
| -------------------- | ----------- | ------------------------- | ------------------------------- | -------------------------- |
| Zone content display | Unit        | `show_zone(N)` for N=1..6 | Correct mineral image displayed | All 6 correct              |
| Standby black        | Unit        | `show_standby()`          | Black screen                    | Pass                       |
| Switch speed         | Performance | Rapid zone switching      | Content changes within 500ms    | Measured with stopwatch    |
| Legibility           | Quality     | Observe from 1m distance  | Text readable without squinting | Subjective, staff approval |

### C4 — Coordinator

| Test               | Type        | Input              | Expected Output                          | Pass Criteria              |
| ------------------ | ----------- | ------------------ | ---------------------------------------- | -------------------------- |
| Touch → Active     | Integration | MQTT `{"zone":3}`  | Lights + projection for zone 3           | Pass                       |
| Timeout → Standby  | Integration | No touch for 45s   | Standby state, lights + projection reset | Pass within ±3s            |
| Re-touch same zone | Integration | Touch zone 3 twice | Timer resets, no visual change           | Pass                       |
| Cross-zone switch  | Integration | Touch Z1, then Z4  | Z4 scene immediately                     | Pass                       |
| PC reboot          | Resilience  | Reboot PC          | Coordinator starts automatically         | Pass within 60s            |
| Log file           | Monitoring  | Run for 1 hour     | All events logged with timestamps        | Log file present, readable |

### Full System Soak Test

- Run 72 hours continuously (simulate touches every 5 minutes via test script)
- Monitor: log file, MQTT heartbeats, no unexpected state transitions
- Pass criteria: 0 crashes, 0 lockups, correct behaviour maintained throughout

---

## 7. Learning Path for Junior Developer

Complete these topics **before starting Phase 1**. Allocate 2 weeks (Phase 0 overlap).

### Week 0: Electronics Foundations

1. **What is a microcontroller?**
   - What to learn: Difference between microcontroller and computer. What GPIO pins are. Voltage levels (3.3V vs 5V).
   - Resource: [ESP32 Introduction — Random Nerd Tutorials](https://randomnerdtutorials.com/getting-started-with-esp32/)
   - Practice: Connect an LED to GPIO2 and blink it

2. **Basic electronics: voltage, current, resistance**
   - What to learn: Ohm's Law (V = I × R). What a pull-up resistor does. Why capacitors matter near sensors.
   - Resource: [Electronics Tutorial — SparkFun](https://learn.sparkfun.com/tutorials/voltage-current-resistance-and-ohms-law)
   - Practice: Calculate what resistor value limits LED current to 10mA at 3.3V

3. **Reading a datasheet**
   - What to learn: How to find pin numbers, voltage ranges, and maximum ratings in a datasheet. Why exceeding Vmax destroys components.
   - Resource: [How to Read a Datasheet — SparkFun](https://learn.sparkfun.com/tutorials/how-to-read-a-datasheet)
   - Practice: Find the maximum safe voltage for an ESP32 GPIO pin in the ESP32 datasheet

4. **Capacitance and touch sensing**
   - What to learn: What capacitance is (charge storage). Why the human body changes capacitance. Why glass attenuates the signal.
   - Resource: [How Capacitive Touch Works — Hackaday](https://hackaday.com/2016/05/12/will-it-touch-the-definitive-capacitive-guide/)
   - Practice: Read the ESP32 touch tutorial and build the basic example

### Week 1: Connectivity

5. **WiFi networking basics**
   - What to learn: What an IP address is. What a port number is. What a router does. How to find device IP addresses on a local network.
   - Resource: [Networking Basics — Cisco Learning Network](https://learningnetwork.cisco.com/s/article/networking-basics)
   - Practice: Find the IP address of your PC and your phone on the same WiFi network

6. **MQTT protocol**
   - What to learn: What a broker is. What topics and payloads are. Publish vs. subscribe. QoS levels (use QoS 1 for reliable delivery).
   - Resource: [MQTT Explained — HiveMQ](https://www.hivemq.com/mqtt-essentials/)
   - Practice: Install MQTT Explorer and subscribe to a public test broker (`test.mosquitto.org`), observe live messages

7. **Python basics for hardware control**
   - What to learn: Functions, classes, threading basics, try/except, logging module
   - Resource: [Python Crash Course — Real Python](https://realpython.com/python-first-steps/)
   - Practice: Write a Python script that prints "Hello" every 5 seconds using `threading.Timer`

### Week 2: Protocols and Tools

8. **DMX512 protocol**
   - What to learn: What DMX is. What a DMX universe is (512 channels). What a DMX address is. Why you need a terminator. What a dimmer pack does.
   - Resource: [DMX512 Tutorial — Enttec Learning Center](https://www.enttec.com/learn-about-dmx/)
   - Practice: Use MQTT Explorer and pyenttec to fade a single DMX channel from 0 to 255

9. **Git version control**
   - What to learn: `git init`, `git add`, `git commit`, `git push`, `.gitignore` (critical for keeping passwords out of git)
   - Resource: [Git Handbook — GitHub](https://guides.github.com/introduction/git-handbook/)
   - Practice: Create a GitHub repository for the project, commit the PlatformIO project, ensure `config.h` is in `.gitignore`

10. **Logging and debugging**
    - What to learn: Python `logging` module. How to write to log files. How to interpret ESP32 serial output. How to use MQTT Explorer for live debugging.
    - Resource: [Python Logging — Real Python](https://realpython.com/python-logging/)
    - Practice: Add file logging to a Python script and verify the log file persists after restart

---

## 8. Full BOM (Bill of Materials)

| Item                           | Description                  | Qty         | Est. Unit Cost   | Est. Total | Supplier              |
| ------------------------------ | ---------------------------- | ----------- | ---------------- | ---------- | --------------------- |
| ESP32 DevKit v1 (38-pin)       | Main touch + WiFi controller | 2 (1 spare) | €8               | €16        | AliExpress, Mouser    |
| Copper foil tape 25mm          | Touch pads on glass          | 2m roll     | €6               | €12        | Amazon, RS Components |
| Shielded 6-core cable 24AWG    | Touch wires to ESP32         | 5m          | €12              | €12        | RS Components         |
| ABS enclosure 120×80×40mm      | ESP32 housing                | 1           | €5               | €5         | Amazon                |
| USB 5V 1A charger + cable      | ESP32 power                  | 1           | €8               | €8         | Amazon                |
| Enttec DMX USB Pro             | PC to DMX bridge             | 1           | €90              | €90        | Enttec, distributor   |
| Showtec Multidim MK3 (4ch)     | DMX dimmer pack (4ch)        | 1           | €180             | €180       | Highlite, DJshop      |
| Showtec Multidim 2ch extension | Additional 2 channels        | 1           | €80              | €80        | Highlite              |
| PAR16 GU10 fixture + mount     | Spotlight housing            | 6           | €30              | €180       | Lighting supplier     |
| GU10 LED 7W 2700K dimmable     | Warm white bulb              | 8 (2 spare) | €5               | €40        | Philips, IKEA         |
| XLR 3-pin DMX cable 3m         | DMX signal cables            | 3           | €8               | €24        | Thomann               |
| XLR 3-pin DMX terminator 120Ω  | End-of-chain terminator      | 1           | €5               | €5         | Thomann               |
| Short-throw projector          | Content display              | 1           | €500             | €500       | BenQ, Epson           |
| Rear projection film           | Back panel of vitrina        | TBD m²      | €15/m²           | ~€100      | Pro Display           |
| HDMI active cable 5m           | PC to projector              | 1           | €15              | €15        | Amazon                |
| Terminal blocks + connectors   | Wire management              | 1 set       | €10              | €10        | RS Components         |
| Cable management clips         | Routing wires neatly         | 1 set       | €5               | €5         | Amazon                |
| PC (dedicated, any modern)     | Central coordinator          | 1           | Existing or €400 | —          | —                     |

**Estimated total materials cost: ~€1,280 – €1,480** (excluding PC if already available, excluding electrician labour)

---

## 9. Risks & Mitigations

| Risk                                               | Probability | Impact   | Mitigation                                                                                                             |
| -------------------------------------------------- | ----------- | -------- | ---------------------------------------------------------------------------------------------------------------------- |
| Touch not working through thick glass              | Medium      | High     | Test copper pad on actual glass ASAP (Phase 1). Fallback: AT42QT1070 with higher sensitivity amplifier                 |
| ESP32 touch drift over time (temperature/humidity) | Medium      | Medium   | ESP32 auto-baseline calibration handles this. Monitor via heartbeat.                                                   |
| WiFi instability in museum                         | Low         | High     | Implement robust MQTT reconnect loop. Consider dedicated WiFi access point for vitrina if shared network is unreliable |
| DMX connection failure (USB disconnect)            | Low         | High     | Implement watchdog in Python that checks DMX health every 30s and alerts via log                                       |
| Projection geometry doesn't fit (throw distance)   | Medium      | Medium   | Measure vitrina depth and projector throw ratio before purchasing. Ultra-short-throw as fallback                       |
| 230V wiring errors                                 | Low         | Critical | Mandatory electrician sign-off before energizing. No exceptions                                                        |
| PC crash overnight                                 | Low         | High     | Auto-start via Task Scheduler. Python coordinator with exception handling that restarts on error                       |
| Content not ready for opening date                 | Medium      | Medium   | Use placeholder images from Phase 1. Decouple content from software development                                        |
| Museum ambient light interfering with projection   | Medium      | Medium   | Test with ambient lights on before finalizing projector choice and film type                                           |

---

## 10. Glossary

| Term                 | Definition                                                                                                                             |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| ADC                  | Analog-to-Digital Converter — converts analog voltage to a digital number                                                              |
| Baseline             | The normal (untouched) capacitance reading from a touch pin. Changes with temperature/humidity. ESP32 auto-tracks this.                |
| Broker               | An MQTT server that receives messages from publishers and forwards them to subscribers                                                 |
| Capacitance          | The ability of a surface to store electric charge. The human body adds capacitance when it approaches a conductor.                     |
| Debounce             | Filtering technique that ignores rapid repeated signals to prevent false readings from a single touch                                  |
| DMX512               | A digital protocol (512 channels) used as the industry standard for controlling stage and architectural lighting                       |
| GPIO                 | General Purpose Input/Output — a programmable pin on a microcontroller that can read or output digital signals                         |
| GU10                 | A type of light bulb base fitting, common in spotlights. Twist-lock fitting.                                                           |
| Heartbeat            | A periodic "I'm alive" message sent by the ESP32 to let the PC know it is still running                                                |
| MQTT                 | Message Queuing Telemetry Transport — a lightweight messaging protocol using publish/subscribe topics, designed for IoT devices        |
| PAR16                | A spotlight fixture type (Parabolic Aluminized Reflector, 16/8" diameter)                                                              |
| PWM                  | Pulse Width Modulation — a way to dim LEDs by rapidly switching them on/off at varying duty cycles                                     |
| QoS                  | Quality of Service in MQTT — QoS 1 means the message is delivered at least once (retry on failure)                                     |
| Rear projection film | A translucent adhesive film applied to glass that diffuses projected light, enabling rear projection displays                          |
| SSR                  | Solid State Relay — an electronic switch that isolates low-voltage control signals from high-voltage AC loads                          |
| State machine        | A programming pattern where the system is always in one defined state (e.g., STANDBY, ACTIVE) and transitions between states on events |
| Throw ratio          | Projector specification: ratio of throw distance to image width. 1.5:1 means 1.5m distance per 1m of image width.                      |
| Watchdog             | A hardware or software timer that resets the microcontroller if the main program stops running                                         |
| XLR                  | A type of locking connector used in professional audio and DMX lighting, with 3 pins                                                   |

---

_Plan generated: 2026-04-20 | Vitrina Interativa de Minerais — Lousal_
_Revision: 1.0_
